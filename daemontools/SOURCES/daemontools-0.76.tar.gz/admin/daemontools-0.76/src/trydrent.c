/* Public domain. */

#include <sys/types.h>
#include <dirent.h>

void foo()
{
  DIR *dir;
  struct dirent *d;
}
